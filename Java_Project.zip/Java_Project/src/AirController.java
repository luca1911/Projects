public class AirController extends Thread{
    private String name;
    private FlightQueue fq;



    public AirController(String name, FlightQueue fq) {
        super();
        this.name = name;
        this.fq = fq;
    }

    @Override
    public void run() {
        while(true){
            Flight a = new Flight();
            try {
                fq.add(a);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }



        }
    }
}

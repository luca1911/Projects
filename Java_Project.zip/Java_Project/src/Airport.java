public class Airport extends Thread{
    private String name;
    private FlightQueue fq;

    public Airport(String name, FlightQueue fq) {
        super();
        this.name = name;
        this.fq = fq;
    }

    @Override
    public void run() {
        while(true){
            String decision;
            Flight i = null;
            try {
                i = fq.remove();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(i.toString());


        }
    }
}

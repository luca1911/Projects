import java.util.LinkedList;
import java.util.ListIterator;

public class FlightRepository {

    LinkedList<Flight> fr = new LinkedList<Flight>();

    public void Add(Flight x){
        fr.add(x);
    }

    public LinkedList get_By_Company(String company){
        LinkedList<Flight> ll = new LinkedList<Flight>();
        ListIterator<Flight> I = fr.listIterator();
        while(I.hasNext()){
            Flight a = I.next();
           if(a.getCompany().equals(company)){
               ll.add(a);
           }
        }
        return ll;
    }

    public LinkedList get_By_Departure_Date(String d){
        LinkedList<Flight> ll = new LinkedList<Flight>();
        ListIterator<Flight> I = fr.listIterator();
        while(I.hasNext()){
            Flight a = I.next();
            if(a.getDeparture_date().equals(d)){
                ll.add(a);
            }
        }
        return ll;
    }

    public LinkedList get_By_Arrival_Date(String d){
        LinkedList<Flight> ll = new LinkedList<Flight>();
        ListIterator<Flight> I = fr.listIterator();
        while(I.hasNext()){
            Flight a = I.next();
            if(a.getArrival_date().equals(d)){
                ll.add(a);
            }
        }
        return ll;
    }

    public LinkedList get_By_Departure_Airport(String d){
        LinkedList<Flight> ll = new LinkedList<Flight>();
        ListIterator<Flight> I = fr.listIterator();
        while(I.hasNext()){
            Flight a = I.next();
            if(a.getDeparture_airport().equals(d)){
                ll.add(a);
            }
        }
        return ll;
    }

    public LinkedList get_By_Arrival_Airport(String d){
        LinkedList<Flight> ll = new LinkedList<Flight>();
        ListIterator<Flight> I = fr.listIterator();
        while(I.hasNext()){
            Flight a = I.next();
            if(a.getArrival_airport().equals(d)){
                ll.add(a);
            }
        }
        return ll;
    }
}

import java.util.HashSet;
import java.util.LinkedList;
import java.util.TreeSet;

public class Main {

    public static void main(String[] args) {

        Flight a = new Flight();
        Flight b = new Flight();
        Flight c = new Flight();

        LinkedList<Flight> l = new LinkedList<Flight>();

        l.add(a);
        l.add(b);
        l.add(c);

        HashSet<Flight> h = new HashSet<Flight>();

        h.add(a);
        h.add(b);
        h.add(c);

        TreeSet<Flight> t = new TreeSet<Flight>();

        t.add(a);
        t.add(b);
        t.add(c);


    }
}

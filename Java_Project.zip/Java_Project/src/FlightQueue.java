import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class FlightQueue {
    private Queue<Flight> queue = new LinkedList<Flight>();
    public static final int MAX_SIZE = 10;
    final Lock lock = new ReentrantLock();
    final Condition notFull = lock.newCondition();
    final Condition notEmpty = lock.newCondition();

    public  void add(Flight a) throws InterruptedException{
        lock.lock();
        while(queue.size() == MAX_SIZE){
            notFull.await();
        }
        queue.add(a);
        notEmpty.signal();
        lock.unlock();

    }

    public  Flight remove() throws InterruptedException{
        lock.lock();
        while(queue.isEmpty())
           notEmpty.await();
        Flight a = queue.remove();
        notFull.signal();
        lock.unlock();
        return a;
    }
}

import java.util.Random;

public class Flight {
    private String company;
    private String departure_date;
    private String arrival_date;
    private String departure_airport;
    private String arrival_airport;


    public Flight(){
        this.company = Generate();
        this.departure_date = Generate();
        this.arrival_date = Generate();
        this.departure_airport = Generate();
        this.arrival_airport = Generate();
    }

    public String getCompany() {
        return company;
    }

    public String getDeparture_date() {
        return departure_date;
    }

    public String getArrival_date() {
        return arrival_date;
    }

    public String getDeparture_airport() {
        return departure_airport;
    }

    public String getArrival_airport() {
        return arrival_airport;
    }

    public String Generate(){
        String chars = "abcdefghijklmnopqrstuvwxyz";
        Random rand = new Random();
        StringBuilder sb = new StringBuilder(5);
        for(int i = 0; i < 5; i++)
            sb.append(chars.charAt(rand.nextInt(chars.length())));
        return sb.toString();
    }

    public String toString(){
        return company + ", "+ departure_date+ ", "+arrival_date + ", " + departure_airport + ", " + arrival_airport;
    }
}

	// Include standard headers
#include <stdio.h>
#include <stdlib.h>
#include <iostream>

// Include GLEW
#include "dependente\glew\glew.h"

// Include GLFW
#include "dependente\glfw\glfw3.h"

// Include GLM
#include "dependente\glm\glm.hpp"
#include "dependente\glm\gtc\matrix_transform.hpp"
#include "dependente\glm\gtc\type_ptr.hpp"

#include "shader.hpp"
#define SPEED 0.4f



glm::vec3 positions[] = {
		//glm::vec3((static_cast <float> (rand()) / static_cast <float> (RAND_MAX)) *x,  0.2f,  0),
		glm::vec3((rand() % 19 - 10) /10.0f,  ((rand() % 15)+3) / 10.0f,  0),
		glm::vec3((rand() % 19 - 10) / 10.0f , ((rand() % 15) + 3) / 10.0f, 0),
		glm::vec3((rand() % 19 - 10) / 10.0f , ((rand() % 15) + 3) / 10.0f, 0),
		glm::vec3((rand() % 19 - 10) / 10.0f , ((rand() % 15) + 3) / 10.0f, 0),
		glm::vec3((rand() % 19 - 10) / 10.0f, ((rand() % 15) + 3) / 10.0f, 0),
		glm::vec3((rand() % 19 - 10) / 10.0f, ((rand() % 15) + 3) / 10.0f, 0),
		glm::vec3((rand() % 19 - 10) / 10.0f, ((rand() % 15) + 3) / 10.0f, 0),
		glm::vec3((rand() % 19 - 10) / 10.0f,  ((rand() % 15) + 3) / 10.0f, 0),
		glm::vec3((rand() % 19 - 10) / 10.0f,  ((rand() % 15) + 3) / 10.0f, 0),
		glm::vec3((rand() % 19 - 10) / 10.0f, ((rand() % 15) + 3) / 10.0f, 0),
		glm::vec3((rand() % 19 - 10) / 10.0f, ((rand() % 15) + 3) / 10.0f, 0),
		glm::vec3((rand() % 19 - 10) / 10.0f, ((rand() % 15) + 3) / 10.0f, 0),
		glm::vec3((rand() % 19 - 10) / 10.0f,  ((rand() % 15) + 3) / 10.0f, 0),
		glm::vec3((rand() % 19 - 10) / 10.0f,  ((rand() % 15) + 3) / 10.0f, 0),
		glm::vec3((rand() % 19 - 10) / 10.0f, ((rand() % 15) + 3) / 10.0f, 0),
		
};

//variables
GLFWwindow* window;
const int width = 1024, height = 1024;
glm::mat4 trans(1.0f);
glm::mat4 bullet(1.0f);
int i = 0;
float shipx = 0.0f, shipy = 0.0f;
float bulletx = -2.0f, bullety;
bool bulletspawn = false;
bool drawasteroid = false;
bool scores = false;
bool reset = true;
int shipHp = 3;
int score;
int wave = 0;
int count = 0;
float time2 = 0;
glm::vec3 position = glm::vec3((rand() % 19 - 10) / 10.0f, 1.1f, 0.0f);
//Time
float deltaTime = 0.0f;	// Time between current frame and last frame
float lastFrame = 0.0f; // Time of last frame
float shipvelocity, bulletvelocity, asteroidvelocity;


void window_callback(GLFWwindow* window, int new_width, int new_height)
{
	glViewport(0, 0, new_width, new_height);
}


int main(void)
{
	
	// Initialise GLFW
	if (!glfwInit())
	{
		fprintf(stderr, "Failed to initialize GLFW\n");
		return -1;
	}

	// Open a window and create its OpenGL context
	window = glfwCreateWindow(width, height, "Exercise 1 HW", NULL, NULL);
	if (window == NULL) {
		fprintf(stderr, "Failed to open GLFW window.");
		glfwTerminate();
		return -1;
	}

	glfwMakeContextCurrent(window);

	// Initialize GLEW
	glewExperimental = true; // Needed for core profile
	if (glewInit() != GLEW_OK) {
		fprintf(stderr, "Failed to initialize GLEW\n");
		glfwTerminate();
		return -1;
	}

	//specify the size of the rendering window
	glViewport(0, 0, width, height);

	// Dark blue background
	glClearColor(0.0f, 0.0f, 0.4f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT);


	// Create and compile our GLSL program from the shaders
	GLuint programID = LoadShaders("SimpleVertexShader.vertexshader", "SimpleFragmentShader.fragmentshader");
	GLuint bulletProgram = LoadShaders("BulletVertexShader.vertexshader", "BulletFragmentShader.fragmentshader");
	GLuint asteroidProgram = LoadShaders("AsteroidSimpleVertexShader.vertexshader", "AsteroidSimpleFragmentShader.fragmentshader");


	GLfloat shipVertices[] = {
		-0.06f, -0.06f, 0.0f,
		 0.06f, -0.06f, 0.0f,
		 0.0f,  0.06f, 0.0f
	};

	GLuint shipIndices[] = {  // note that we start from 0!
		0, 2, 1,
	};

	GLfloat bulletVertices[] = {
		shipx - 0.005, shipy, 0,
		shipx + 0.005, shipy, 0,
		shipx, shipy + 0.05, 0,
	};

	GLuint bulletIndices[] = { 
			0, 2, 1,
		};

	GLfloat Asteroidvertices[] = {
		0.0f, 0.0f, 0.0f,
		-0.07f,-0.1f, 0.0f,
		-0.1f, 0.03f, 0.0f,
		0.0f, 0.1f, 0.0f,
		0.1f, 0.03f, 0.0f,
		0.07, -0.1f, 0.0f,

	};

	GLuint Asteroidindices[] = {  // note that we start from 0!
		0, 1, 2,
		0, 2, 3,
		0, 3, 4,
		0, 4, 5,
		0, 1, 5,
		// first Triangle 
	};



	// A Vertex Array Object (VAO) is an object which contains one or more Vertex Buffer Objects and is designed to store the information for a complete rendered object. 
	GLuint shipvbo, shipvao, shipibo, bulletvbo, bulletvao, bulletibo;
	glGenVertexArrays(1, &shipvao);
	glGenBuffers(1, &shipvbo);
	glGenBuffers(1, &shipibo);
	glGenVertexArrays(1, &bulletvao);
	glGenBuffers(1, &bulletvbo);
	glGenBuffers(1, &bulletibo);

	//bindings ship
	glBindVertexArray(shipvao);
	glBindBuffer(GL_ARRAY_BUFFER, shipvbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(shipVertices), shipVertices, GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shipibo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(shipIndices), shipIndices, GL_STATIC_DRAW);

	//set attribute pointers
	glVertexAttribPointer(
		0,                  // attribute 0, must match the layout in the shader.
		3,                  // size of each attribute
		GL_FLOAT,           // type
		GL_FALSE,           // normalized?
		3 * sizeof(float),  // stride
		(void*)0            // array buffer offset
	);
	glEnableVertexAttribArray(0);

	//bindings bullet
	glBindVertexArray(bulletvao);
	glBindBuffer(GL_ARRAY_BUFFER, bulletvbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(bulletVertices), bulletVertices, GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bulletibo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(bulletIndices), bulletIndices, GL_STATIC_DRAW);
	glVertexAttribPointer(
		0,                  // attribute 0, must match the layout in the shader.
		3,                  // size of each attribute
		GL_FLOAT,           // type
		GL_FALSE,           // normalized?
		3 * sizeof(float),  // stride
		(void*)0            // array buffer offset
	);
	glEnableVertexAttribArray(0);

	GLuint vbo3, vao3, ibo3;
	glGenVertexArrays(1, &vao3);
	glGenBuffers(1, &vbo3);
	glGenBuffers(1, &ibo3);

	glBindVertexArray(vao3);

	glBindBuffer(GL_ARRAY_BUFFER, vbo3);
	glBufferData(GL_ARRAY_BUFFER, sizeof(Asteroidvertices), Asteroidvertices, GL_STATIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo3);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(Asteroidindices), Asteroidindices, GL_STATIC_DRAW);

	//set attribute pointers
	glVertexAttribPointer(
		0,                  // attribute 0, must match the layout in the shader.
		3,                  // size of each attribute
		GL_FLOAT,           // type
		GL_FALSE,           // normalized?
		3 * sizeof(float),                  // stride
		(void*)0            // array buffer offset
	);
	glEnableVertexAttribArray(0);
	
	glfwSetFramebufferSizeCallback(window, window_callback);
	

	// Check if the window was closed
	while (!glfwWindowShouldClose(window))
	{
		
		
		shipvelocity = SPEED * deltaTime;
		bulletvelocity = SPEED * 3 * deltaTime;
		//asteroidvelocity = SPEED * 0.25 * deltaTime;
		if (wave == 3) {
			if (glfwGetTime() - time2 >= 10 && glfwGetTime() - time2 <= 20) {
				glClearColor(0.5f, 0.5f, 0.0f, 0.0f);
				asteroidvelocity = SPEED * 0.5 * deltaTime;
			}
			else if (glfwGetTime() - time2 > 20) {
				glClearColor(0.5f, 0.0f, 0.0f, 0.0f);
				asteroidvelocity = SPEED * deltaTime;
			}
			else {
				asteroidvelocity = SPEED * 0.25 * deltaTime;
			}
		}
		if(wave == 1)
		{
			int i = 0;
			
			while (i < 5) {

				glUseProgram(asteroidProgram);
				glm::mat4 asteroid;

				asteroid = glm::translate(asteroid, positions[i] -= glm::vec3(0.0f, asteroidvelocity, 0.0f));

				unsigned int transformlocasteroid1 = glGetUniformLocation(asteroidProgram, "transform");
				glUniformMatrix4fv(transformlocasteroid1, 1, GL_FALSE, glm::value_ptr(asteroid));

				unsigned int transformlocasteroid2 = glGetUniformLocation(asteroidProgram, "color");
				glUniform4fv(transformlocasteroid2, 1, glm::value_ptr(glm::vec3(0.0f, 1.0f, 0.0)));

				//bind vao
				glBindVertexArray(vao3);
				glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
				
				if (positions[i].y <= -1.0f) {
					positions[i] = glm::vec3(2.0f, 100.1f, 0.0f);
					count += 1;

				}
				if (positions[i].y >= bullety - 0.1 && positions[i].y <= bullety + 0.1 && positions[i].x >= bulletx - 0.1 && positions[i].x <= bulletx + 0.1) {
					positions[i] = glm::vec3(2.0f, 100.1f, 0.0f);
					count += 1;
					bulletspawn = false;
					bullety = -2.0f;
					score += 1;
				}

				if (positions[i].y >= shipy - 0.1 && positions[i].y <= shipy + 0.1 && positions[i].x >= shipx - 0.1 && positions[i].x <= shipx + 0.1) {
					//glfwTerminate();
					shipHp -= 1;
					std::cout << "remaining lives: " << shipHp << '\n';
					positions[i] = glm::vec3(2.0f, 100.1f, 0.0f);
					count += 1;


				}
				if (count == 5) { reset = true; }
				i++;
			}
			
		}
		if (reset) {
			int i = 0;
			while (i < 15) {
				positions[i] = glm::vec3((rand() % 19 - 10) / 10.0f, ((rand() % 15) + 10) / 10.0f, 0);
				i++;
			}
			reset = false;
			wave++;
			std::cout << "wave: " << wave <<'\n';
			count = 0;
			if (wave == 3) {
				time2 = glfwGetTime();
			}

		}
		 if (wave == 2) {
			 int i = 0;
			 
			while (i < 10) {
				glUseProgram(asteroidProgram);
				glm::mat4 asteroid;

				asteroid = glm::translate(asteroid, positions[i] -= glm::vec3(0.0f, asteroidvelocity, 0.0f));

				unsigned int transformlocasteroid1 = glGetUniformLocation(asteroidProgram, "transform");
				glUniformMatrix4fv(transformlocasteroid1, 1, GL_FALSE, glm::value_ptr(asteroid));

				unsigned int transformlocasteroid2 = glGetUniformLocation(asteroidProgram, "color");
				glUniform4fv(transformlocasteroid2, 1, glm::value_ptr(glm::vec3(0.0f, 1.0f, 0.0)));

				//bind vao
				glBindVertexArray(vao3);
				glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
				
				if (positions[i].y <= -1.0f) {
					positions[i] = glm::vec3(2.0f, 100.1f, 0.0f);
					count++;

				}
				if (positions[i].y >= bullety - 0.1 && positions[i].y <= bullety + 0.1 && positions[i].x >= bulletx - 0.1 && positions[i].x <= bulletx + 0.1) {
					positions[i] = glm::vec3(2.0f, 100.1f, 0.0f);
					bulletspawn = false;
					bullety = -2.0f;
					score += 1;
					count++;
				}

				if (positions[i].y >= shipy - 0.1 && positions[i].y <= shipy + 0.1 && positions[i].x >= shipx - 0.1 && positions[i].x <= shipx + 0.1) {
					//glfwTerminate();
					shipHp -= 1;
					std::cout << "remaining lives: " << shipHp << '\n';
					positions[i] = glm::vec3(2.0f, 100.1f, 0.0f);
					count++;


				}
				if (count == 10) { reset = true; }
				i++;
			}
			
			

			
		}
		 if (wave == 3) {
			 

			i = 0;
			while (i < 15) {
				glUseProgram(asteroidProgram);
				glm::mat4 asteroid;

				asteroid = glm::translate(asteroid, positions[i] -= glm::vec3(0.0f, asteroidvelocity, 0.0f));

				unsigned int transformlocasteroid1 = glGetUniformLocation(asteroidProgram, "transform");
				glUniformMatrix4fv(transformlocasteroid1, 1, GL_FALSE, glm::value_ptr(asteroid));

				unsigned int transformlocasteroid2 = glGetUniformLocation(asteroidProgram, "color");
				glUniform4fv(transformlocasteroid2, 1, glm::value_ptr(glm::vec3(0.0f, 1.0f, 0.0)));

				//bind vao
				glBindVertexArray(vao3);
				glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
				
				if (positions[i].y <= -1.0f) {
					positions[i] = glm::vec3((rand() % 19 - 10) / 10.0f, 1.1f, 0.0f);

				}
				if (positions[i].y >= bullety - 0.1 && positions[i].y <= bullety + 0.1 && positions[i].x >= bulletx - 0.1 && positions[i].x <= bulletx + 0.1) {
					positions[i] = glm::vec3((rand() % 19 - 10) / 10.0f, 1.1f, 0.0f);
					bulletspawn = false;
					bullety = -2.0f;
					score += 1;
				}

				if (positions[i].y >= shipy - 0.1 && positions[i].y <= shipy + 0.1 && positions[i].x >= shipx - 0.1 && positions[i].x <= shipx + 0.1) {
					//glfwTerminate();
					shipHp -= 1;
					std::cout << "remaining lives: " << shipHp << '\n';
					positions[i] = glm::vec3((rand() % 19 - 10) / 10.0f, 1.1f, 0.0f);


				}
				i++;
			}


		}

	
		if (shipHp == 0) {
			scores = true;
			
			
			
			
		}
		if (scores) {
			std::cout << "your final score is:" << score;
			scores = false;
			
			glfwTerminate();
			shipHp = 1;
		}

		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;
		// Swap buffers
		glfwSwapBuffers(window);
		// Check for events
		glfwPollEvents();

		// Clear the screen
		glClear(GL_COLOR_BUFFER_BIT);

		//set velocities
		shipvelocity = SPEED * deltaTime;
		bulletvelocity = SPEED * 3 * deltaTime;
		asteroidvelocity = SPEED * 0.25 * deltaTime;

		// Use our shader
		glUseProgram(programID);

		//bind VAO
		glBindVertexArray(shipvao);

		//is the order (translate, than rotate) important?
		//trans = glm::translate(trans, positions[0]);
		//trans = glm::rotate(trans, 1.0f, glm::vec3(0.0, 0.0, 1.0));
		//trans = glm::rotate(trans, (float)glfwGetTime() * 100, glm::vec3(0.0, 0.0, 1.0));

		// send variables to shader
			
		//transform matrix
		unsigned int transformLoc = glGetUniformLocation(programID, "transform");
		glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(trans));

		glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, 0);
		
		//if (glfwGetKey(window, GLFW_KEY_ESCAPE)) glfwSetWindowShouldClose(window,true);
		//if(glfwGetMouseButton(window,GLFW_MOUSE_BUTTON_RIGHT)) trans = glm::rotate(trans, 0.10f, glm::vec3(0.0, 0.0, 1.0));
		//if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT)) trans = glm::rotate(trans, -0.10f, glm::vec3(0.0, 0.0, 1.0));
		if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT)) {
			
			bullety = shipy;
			bulletx = shipx;
			//std::cout << bullety << " " << bulletx << '\n';
			bulletspawn = true;
		}

		if (bulletspawn == true) {
			glUseProgram(bulletProgram);
			glBindVertexArray(bulletvao);
			//glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, 0);
			unsigned int transformLocBullet = glGetUniformLocation(bulletProgram, "transform");
			glUniformMatrix4fv(transformLocBullet, 1, GL_FALSE, glm::value_ptr(bullet));
			//std::cout << bullety << " " << bulletx << '\n';
			if (bullety <= 0.95f)
			{	
				bullet = glm::mat4(1);
				bullet = glm::translate(bullet, glm::vec3(bulletx, bullety, 0));
				bullety += bulletvelocity;
				//std::cout << bullety;
			}
			else
			{
				bulletspawn = false;
				bullety = -2.0f;
			}
			//glBindVertexArray(bulletvao);
			glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, 0);
		}


		if (glfwGetKey(window,GLFW_KEY_W)) {
			if (shipy < 0.9f)
			{
				//std::cout << x;
				trans = glm::mat4(1);
				shipy += shipvelocity;
				trans = glm::translate(trans, glm::vec3(shipx, shipy, 0));
			}
		}
		if (glfwGetKey(window, GLFW_KEY_A)) {

			if (shipx > -0.9f)
			{
				//std::cout << x;
				trans = glm::mat4(1);
				shipx -= shipvelocity;
				trans = glm::translate(trans, glm::vec3(shipx, shipy, 0));
			}
		}
		if (glfwGetKey(window, GLFW_KEY_S)) {

			if (shipy > -0.9f)
			{
				//std::cout << x;
				trans = glm::mat4(1);
				shipy -= shipvelocity;
				trans = glm::translate(trans, glm::vec3(shipx, shipy, 0));
			}
		}
		if (glfwGetKey(window, GLFW_KEY_D)) {
			
			if (shipx < 0.9f)
			{
				//std::cout << x;
				trans = glm::mat4(1);
				shipx += shipvelocity;
				trans = glm::translate(trans, glm::vec3(shipx, shipy, 0));
			}
		}
		if (glfwGetKey(window, GLFW_KEY_E)) {
			drawasteroid = true;
			


			
		}

		if (drawasteroid == true) {
			glm::mat4 asteroid;

			glUseProgram(asteroidProgram);
			asteroid = glm::translate(asteroid, position -= glm::vec3(0.0f, asteroidvelocity, 0.0f));
			unsigned int transformlocasteroid1 = glGetUniformLocation(asteroidProgram, "transform");
			glUniformMatrix4fv(transformlocasteroid1, 1, GL_FALSE, glm::value_ptr(asteroid));

			unsigned int transformlocasteroid2 = glGetUniformLocation(asteroidProgram, "color");
			glUniform4fv(transformlocasteroid2, 1, glm::value_ptr(glm::vec3(0.0f, 1.0f, 0.0)));
			glBindVertexArray(vao3);
			glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);

			if (position.y <= -1.0f) {
				positions[i] = glm::vec3((rand() % 19 - 10) / 10.0f, 1.1f, 0.0f);

			}
			if (position.y >= bullety - 0.1 && position.y <= bullety + 0.1 && position.x >= bulletx - 0.1 && position.x <= bulletx + 0.1) {
				position = glm::vec3((rand() % 19 - 10) / 10.0f, 1.1f, 0.0f);
				bulletspawn = false;
				bullety = -2.0f;
				score += 1;
			}

			if (position.y >= shipy - 0.1 && position.y <= shipy + 0.1 && position.x >= shipx - 0.1 && position.x <= shipx + 0.1) {
				//glfwTerminate();
				shipHp -= 1;
				std::cout << "remaining lives: " << shipHp << '\n';
				positions[i] = glm::vec3((rand() % 19 - 10) / 10.0f, 1.1f, 0.0f);


			}
			

		}
		
		
	}
	

	// Cleanup
	glDeleteBuffers(1, &shipvbo);
	glDeleteBuffers(1, &shipibo);
	glDeleteVertexArrays(1, &shipvao);
	glDeleteBuffers(1, &bulletvbo);
	glDeleteBuffers(1, &bulletibo);
	glDeleteVertexArrays(1, &bulletvao);
	glDeleteProgram(programID);
	glDeleteProgram(bulletProgram);

	// Close OpenGL window and terminate GLFW
	glfwTerminate();

	return 0;
}